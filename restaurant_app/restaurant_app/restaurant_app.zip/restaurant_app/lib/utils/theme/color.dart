import 'package:flutter/material.dart';

const primary = Color(0xff319795);
const shimmer = Color(0xffEDF2F7);
const border =  Color(0xff718096);
const black = Color(0xff000000);
const white = Color(0xffFFFFFF);