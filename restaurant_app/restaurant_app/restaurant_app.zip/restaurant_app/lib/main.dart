import 'package:flutter/material.dart';
import 'package:restaurant_app/restaurant_app.dart';

void main() {
  runApp(const RestaurantApp());
}

